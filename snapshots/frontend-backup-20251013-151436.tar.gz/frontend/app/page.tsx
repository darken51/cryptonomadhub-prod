'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { LegalDisclaimer } from '@/components/LegalDisclaimer'
import { Footer } from '@/components/Footer'
import LanguageSwitcher from '@/components/LanguageSwitcher'
import { useTranslations } from 'next-intl'
import {
  Globe,
  TrendingUp,
  Shield,
  Zap,
  ArrowRight,
  Check,
  Star,
  Users,
  Activity,
  BarChart3,
  MessageCircle,
  FileText
} from 'lucide-react'

export default function Home() {
  const t = useTranslations('home')
  const tCommon = useTranslations('common')
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)

    // Scroll animation observer
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible')
          }
        })
      },
      { threshold: 0.1 }
    )

    document.querySelectorAll('.scroll-animate').forEach((el) => {
      observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Header Navigation */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Globe className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gradient hidden sm:inline">
                NomadCrypto Hub
              </span>
            </Link>

            {/* Navigation Links - Desktop */}
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/pricing" className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition">
                Pricing
              </Link>
              <Link href="/countries" className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition">
                Countries
              </Link>
              <Link href="/chat" className="text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition">
                AI Chat
              </Link>
            </nav>

            {/* Right Side: Language + Auth Buttons */}
            <div className="flex items-center gap-3">
              <LanguageSwitcher variant="dropdown" />

              <Link
                href="/auth/login"
                className="px-4 py-2 text-sm font-semibold text-gray-700 dark:text-gray-300 hover:text-purple-600 dark:hover:text-purple-400 transition"
              >
                Login
              </Link>

              <Link
                href="/auth/register"
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-sm font-semibold rounded-lg hover:shadow-lg hover:scale-105 transition-all duration-300"
              >
                Sign Up
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section - Premium (Compact) */}
      <section className="relative py-16 md:py-24 lg:py-32 overflow-hidden">
        {/* Animated background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-500 opacity-10 dark:opacity-20 animate-gradient-shift"></div>

        {/* Floating shapes */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-cyan-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-float" style={{ animationDelay: '4s' }}></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Badge */}
          <div className={`inline-flex items-center gap-2 px-4 py-2 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-full shadow-lg mb-6 ${mounted ? 'animate-fade-in-up' : 'opacity-0'}`}>
            <Star className="w-4 h-4 text-yellow-500" fill="currentColor" />
            <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">
              Trusted by 10,000+ crypto investors worldwide
            </span>
          </div>

          {/* Hero Title */}
          <h1 className={`text-4xl md:text-5xl lg:text-6xl font-extrabold mb-4 ${mounted ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.1s' }}>
            <span className="text-gradient-animated">
              {t('hero.title')}
            </span>
          </h1>

          {/* Subtitle */}
          <p className={`text-lg md:text-xl text-gray-600 dark:text-gray-300 mb-3 max-w-3xl mx-auto ${mounted ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
            {t('hero.subtitle')}
          </p>

          <p className={`text-sm md:text-base text-gray-500 dark:text-gray-400 mb-8 max-w-2xl mx-auto ${mounted ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.3s' }}>
            {t('hero.description')}
          </p>

          {/* CTA Buttons */}
          <div className={`flex flex-col sm:flex-row justify-center gap-3 mb-10 ${mounted ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
            <Link
              href="/auth/register"
              className="group relative px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl font-bold hover:shadow-2xl hover:scale-105 transition-all duration-300 overflow-hidden"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                {t('cta.getStarted')}
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-700 to-blue-700 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </Link>
            <Link
              href="/pricing"
              className="px-6 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-2 border-gray-300 dark:border-gray-600 rounded-xl font-bold hover:shadow-xl hover:scale-105 transition-all duration-300"
            >
              View Plans
            </Link>
          </div>

          {/* Stats */}
          <div className={`grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-12 ${mounted ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.5s' }}>
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient">98</div>
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Countries</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient">10k+</div>
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient">$50M+</div>
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Tax Savings</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient">5</div>
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Blockchains</div>
            </div>
          </div>

          {/* Quick Features Preview */}
          <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto ${mounted ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.6s' }}>
            <div className="flex items-center justify-center gap-2 p-3 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-md">
              <Globe className="w-5 h-5 text-purple-600" />
              <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">Multi-Country</span>
            </div>
            <div className="flex items-center justify-center gap-2 p-3 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-md">
              <MessageCircle className="w-5 h-5 text-blue-600" />
              <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">AI Assistant</span>
            </div>
            <div className="flex items-center justify-center gap-2 p-3 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-md">
              <Activity className="w-5 h-5 text-emerald-600" />
              <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">DeFi Audit</span>
            </div>
            <div className="flex items-center justify-center gap-2 p-3 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-md">
              <FileText className="w-5 h-5 text-orange-600" />
              <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">PDF Reports</span>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 scroll-animate">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Get started in 3 simple steps and optimize your crypto taxes in minutes
            </p>
          </div>

          <div className="relative">
            {/* Timeline line */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-purple-600 via-blue-600 to-cyan-600"></div>

            {/* Steps */}
            <div className="space-y-16">
              {/* Step 1 */}
              <div className="relative scroll-animate">
                <div className="md:flex items-center">
                  <div className="md:w-1/2 md:pr-12 mb-8 md:mb-0 text-right">
                    <div className="inline-block p-3 bg-purple-100 dark:bg-purple-900/30 rounded-2xl mb-4">
                      <Users className="w-8 h-8 text-purple-600 dark:text-purple-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                      Create Your Account
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Sign up for free in 30 seconds. No credit card required to start.
                    </p>
                  </div>
                  <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full items-center justify-center z-10 border-4 border-white dark:border-gray-900">
                    <span className="text-white font-bold">1</span>
                  </div>
                  <div className="md:w-1/2 md:pl-12"></div>
                </div>
              </div>

              {/* Step 2 */}
              <div className="relative scroll-animate" style={{ animationDelay: '0.2s' }}>
                <div className="md:flex items-center">
                  <div className="md:w-1/2 md:pr-12"></div>
                  <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-full items-center justify-center z-10 border-4 border-white dark:border-gray-900">
                    <span className="text-white font-bold">2</span>
                  </div>
                  <div className="md:w-1/2 md:pl-12 mb-8 md:mb-0">
                    <div className="inline-block p-3 bg-blue-100 dark:bg-blue-900/30 rounded-2xl mb-4">
                      <BarChart3 className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                      Connect & Analyze
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Connect your wallet or enter your transaction data. Our AI analyzes everything automatically.
                    </p>
                  </div>
                </div>
              </div>

              {/* Step 3 */}
              <div className="relative scroll-animate" style={{ animationDelay: '0.4s' }}>
                <div className="md:flex items-center">
                  <div className="md:w-1/2 md:pr-12 mb-8 md:mb-0 text-right">
                    <div className="inline-block p-3 bg-cyan-100 dark:bg-cyan-900/30 rounded-2xl mb-4">
                      <FileText className="w-8 h-8 text-cyan-600 dark:text-cyan-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                      Get Your Report
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Download professional PDF reports with complete tax calculations and recommendations.
                    </p>
                  </div>
                  <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 w-12 h-12 bg-gradient-to-br from-cyan-600 to-teal-600 rounded-full items-center justify-center z-10 border-4 border-white dark:border-gray-900">
                    <span className="text-white font-bold">3</span>
                  </div>
                  <div className="md:w-1/2 md:pl-12"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Showcase - Enhanced */}
      <section className="py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 scroll-animate">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Powerful Features
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Everything you need to optimize your crypto taxes across the globe
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 - 98 Countries */}
            <div className="group scroll-animate hover-lift bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Globe className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                {t('features.countries.title')}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {t('features.countries.description')}
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Official 2025 tax data
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Auto-updated weekly
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Multi-source verification
                </li>
              </ul>
            </div>

            {/* Feature 2 - AI Chat */}
            <div className="group scroll-animate hover-lift bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700" style={{ animationDelay: '0.1s' }}>
              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <MessageCircle className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                {t('features.aiChat.title')}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {t('features.aiChat.description')}
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Natural language queries
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Explain Decision mode
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  24/7 availability
                </li>
              </ul>
            </div>

            {/* Feature 3 - DeFi Audit */}
            <div className="group scroll-animate hover-lift bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20 rounded-2xl p-8 shadow-lg border-2 border-emerald-300 dark:border-emerald-700 relative overflow-hidden" style={{ animationDelay: '0.2s' }}>
              <div className="absolute top-0 right-0 bg-emerald-500 text-white text-xs font-bold px-3 py-1 rounded-bl-xl">
                {tCommon('new')}
              </div>
              <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Activity className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                {t('features.defiAudit.title')}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {t('features.defiAudit.description')}
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  5 blockchains supported
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Uniswap, Aave, Compound
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Tax categorization
                </li>
              </ul>
            </div>

            {/* Feature 4 - PDF Reports */}
            <div className="group scroll-animate hover-lift bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700" style={{ animationDelay: '0.3s' }}>
              <div className="w-14 h-14 bg-gradient-to-br from-orange-500 to-red-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <FileText className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                {t('features.pdfReports.title')}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {t('features.pdfReports.description')}
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Professional templates
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Legal disclaimers included
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  One-click download
                </li>
              </ul>
            </div>

            {/* Feature 5 - Real-time */}
            <div className="group scroll-animate hover-lift bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700" style={{ animationDelay: '0.4s' }}>
              <div className="w-14 h-14 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Zap className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                Real-time Updates
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Tax laws change? We update instantly so you're always compliant.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Automatic sync
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Change notifications
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  Historical tracking
                </li>
              </ul>
            </div>

            {/* Feature 6 - Secure */}
            <div className="group scroll-animate hover-lift bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-700" style={{ animationDelay: '0.5s' }}>
              <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Shield className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                Bank-level Security
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Your data is encrypted and protected with enterprise-grade security.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  256-bit encryption
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  GDPR compliant
                </li>
                <li className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Check className="w-4 h-4 text-green-500 mr-2" />
                  No data selling
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Competitor Comparison */}
      <section className="py-24 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 scroll-animate">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Why Choose NomadCrypto Hub?
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Compare us with leading competitors and see the difference
            </p>
          </div>

          <div className="overflow-x-auto scroll-animate">
            <table className="w-full bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
              <thead className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                <tr>
                  <th className="px-6 py-4 text-left font-bold">Feature</th>
                  <th className="px-6 py-4 text-center font-bold">NomadCrypto Hub</th>
                  <th className="px-6 py-4 text-center font-bold text-white/60">Competitor A</th>
                  <th className="px-6 py-4 text-center font-bold text-white/60">Competitor B</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                <tr className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">Countries Supported</td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-green-600 dark:text-green-400 font-bold text-lg">98</span>
                  </td>
                  <td className="px-6 py-4 text-center text-gray-500">30</td>
                  <td className="px-6 py-4 text-center text-gray-500">15</td>
                </tr>
                <tr className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">DeFi Audit</td>
                  <td className="px-6 py-4 text-center">
                    <Check className="w-6 h-6 text-green-600 dark:text-green-400 mx-auto" />
                  </td>
                  <td className="px-6 py-4 text-center text-gray-400">✗</td>
                  <td className="px-6 py-4 text-center text-gray-400">✗</td>
                </tr>
                <tr className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">AI Chat Assistant</td>
                  <td className="px-6 py-4 text-center">
                    <Check className="w-6 h-6 text-green-600 dark:text-green-400 mx-auto" />
                  </td>
                  <td className="px-6 py-4 text-center text-gray-400">Limited</td>
                  <td className="px-6 py-4 text-center text-gray-400">✗</td>
                </tr>
                <tr className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">Explain Decision</td>
                  <td className="px-6 py-4 text-center">
                    <Check className="w-6 h-6 text-green-600 dark:text-green-400 mx-auto" />
                  </td>
                  <td className="px-6 py-4 text-center text-gray-400">✗</td>
                  <td className="px-6 py-4 text-center text-gray-400">✗</td>
                </tr>
                <tr className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">Auto-update Tax Data</td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-green-600 dark:text-green-400 font-semibold">Weekly</span>
                  </td>
                  <td className="px-6 py-4 text-center text-gray-500">Monthly</td>
                  <td className="px-6 py-4 text-center text-gray-500">Manual</td>
                </tr>
                <tr className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition">
                  <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">Starting Price</td>
                  <td className="px-6 py-4 text-center">
                    <span className="text-green-600 dark:text-green-400 font-bold">$20/mo</span>
                  </td>
                  <td className="px-6 py-4 text-center text-gray-500">$49/mo</td>
                  <td className="px-6 py-4 text-center text-gray-500">$99/mo</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="text-center mt-12 scroll-animate">
            <Link
              href="/auth/register"
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl font-bold text-lg hover:shadow-2xl hover:scale-105 transition-all duration-300"
            >
              Start Free Trial
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Social Proof / Stats */}
      <section className="py-24 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 scroll-animate">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Trusted by Thousands Worldwide
            </h2>
            <p className="text-xl text-blue-100">
              Join the crypto investors who've saved millions in taxes
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div className="scroll-animate">
              <div className="text-5xl font-bold mb-2">$50M+</div>
              <div className="text-blue-100">Total Tax Savings</div>
            </div>
            <div className="scroll-animate" style={{ animationDelay: '0.1s' }}>
              <div className="text-5xl font-bold mb-2">10,000+</div>
              <div className="text-blue-100">Active Users</div>
            </div>
            <div className="scroll-animate" style={{ animationDelay: '0.2s' }}>
              <div className="text-5xl font-bold mb-2">98</div>
              <div className="text-blue-100">Countries Covered</div>
            </div>
            <div className="scroll-animate" style={{ animationDelay: '0.3s' }}>
              <div className="text-5xl font-bold mb-2">4.9/5</div>
              <div className="text-blue-100">User Rating</div>
            </div>
          </div>

          {/* Testimonials */}
          <div className="mt-20 grid md:grid-cols-3 gap-8">
            <div className="scroll-animate glass rounded-2xl p-8">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400" fill="currentColor" />
                ))}
              </div>
              <p className="text-blue-50 mb-4">
                "Saved me over $30k in taxes by moving to Portugal. The AI chat answered all my questions instantly."
              </p>
              <div className="font-semibold">— Alex M., Digital Nomad</div>
            </div>
            <div className="scroll-animate glass rounded-2xl p-8" style={{ animationDelay: '0.1s' }}>
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400" fill="currentColor" />
                ))}
              </div>
              <p className="text-blue-50 mb-4">
                "The DeFi audit feature is a game-changer. Found transactions I completely forgot about!"
              </p>
              <div className="font-semibold">— Sarah K., Crypto Investor</div>
            </div>
            <div className="scroll-animate glass rounded-2xl p-8" style={{ animationDelay: '0.2s' }}>
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400" fill="currentColor" />
                ))}
              </div>
              <p className="text-blue-50 mb-4">
                "Way better than TurboTax for crypto. The PDF reports are super professional and detailed."
              </p>
              <div className="font-semibold">— James L., Trader</div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center scroll-animate">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Ready to Optimize Your Crypto Taxes?
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
            Join 10,000+ investors who are already saving millions with NomadCrypto Hub
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-8">
            <Link
              href="/auth/register"
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl font-bold text-lg hover:shadow-2xl hover:scale-105 transition-all duration-300"
            >
              Start Free Trial
            </Link>
            <Link
              href="/pricing"
              className="px-8 py-4 bg-white dark:bg-gray-900 text-gray-900 dark:text-white border-2 border-gray-300 dark:border-gray-600 rounded-xl font-bold text-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
            >
              View Pricing
            </Link>
          </div>
          <p className="text-sm text-gray-500">
            No credit card required • 14-day free trial • Cancel anytime
          </p>
        </div>
      </section>

      {/* Compact Disclaimer */}
      <section className="py-12 bg-yellow-50 dark:bg-yellow-900/20 border-t border-yellow-200 dark:border-yellow-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-start gap-4">
            <Shield className="w-6 h-6 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-yellow-900 dark:text-yellow-200 mb-2">
                Important Legal Disclaimer
              </h3>
              <p className="text-sm text-yellow-800 dark:text-yellow-300">
                NomadCrypto Hub provides general information only and is <strong>NOT</strong> financial, tax, or legal advice.
                Tax laws vary by jurisdiction and change frequently. Always consult licensed professionals (CPA, tax attorney)
                before making financial decisions. We bear no liability for tax penalties or legal consequences.
              </p>
              <div className="mt-3 flex gap-4 text-sm">
                <Link href="/terms" className="text-yellow-700 dark:text-yellow-300 hover:underline font-medium">
                  Terms of Service
                </Link>
                <Link href="/privacy" className="text-yellow-700 dark:text-yellow-300 hover:underline font-medium">
                  Privacy Policy
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
